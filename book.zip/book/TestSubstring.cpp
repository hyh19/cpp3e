#include <iostream>
#include "Substring.h"
using namespace std;

int main()
{
  char *s = "Atlanta, Georgia";
  cout << substring(s, 0, 7);
  return 0;
}
