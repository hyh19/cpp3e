#include <iostream>
using namespace std;

int main()
{
  int count = 1;
  int& r = count;
  cout << "count is " << count << endl;
  cout << "r is " << r << endl;

  r++;
  cout << "count is " << count << endl;
  cout << "r is " << r << endl;

  count = 10;
  cout << "count is " << count << endl;
  cout << "r is " << r << endl;

  return 0;
}
