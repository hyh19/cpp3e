bool isEven(int number)
{
  return (number % 2 == 0);
}