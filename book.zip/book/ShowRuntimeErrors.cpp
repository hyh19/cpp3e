#include <iostream>
using namespace std;

int main()
{
	int i = 4;
	int j = 0;
  cout << i / j << endl;

	return 0;
}

