class A
{
public:
  A()
  {
    // do something;
  }

  double f1()
  {
    // return a number
  }

  double f2();
};

