#include <iostream>
#include "MyLib.h"

using namespace std;

int main()
{
  cout << (isEven(4) ? "true" : "false") << endl;
  cout << (isEven(5) ? "true" : "false") << endl;

  return 0;
}
