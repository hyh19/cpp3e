#include <iostream>
using namespace std

int main()
{
  cout << "Programming is fun << endl; 

  return 0;
}