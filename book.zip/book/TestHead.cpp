#include "Circle.h"
#include "Head.h"

int main()
{
  // Other code in TestHead.cpp omitted
}
