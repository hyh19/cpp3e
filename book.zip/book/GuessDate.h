#ifndef GUESSDATE_H
#define GUESSDATE_H

class GuessDate
{
public:

private:
  int dates[3] = {1, 2, 3};
};

#endif
