#include <iostream>
using namespace std;

int main()
{
  cout << "Programming is fun!" << endl;
  cout << "Fundamentals First" << endl;
  cout << "Problem Driven" << endl;

  return 0;
}
