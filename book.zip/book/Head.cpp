#include "Circle.h"
// Other code in Head.h omitted
