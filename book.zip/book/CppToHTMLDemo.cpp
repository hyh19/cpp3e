#include <iostream>
#include "head.h"
using namespace std;

int main()
{
  // Display Welcome to C++ to the console
  cout << "Welcome to C++!" << endl;

  /* block comment
     3434
  */

  int v0 = .5;
  int v1 = 0.5;
  int v2 = -0.5;
  int v3 = +0.5; // Rarely used this way, ignore it

  int v4 = static_cast<int>(v3);

  int v5 = 4 - 5;
  int v5 = 4 +5;
  int v5 = 4 + 5;
  int v6 = 4 / 5;

  int x = v[3] + v[3];
  v vector(3);
  v.size() < 4;
  v3.size() < 4;
  v3.size() <4;
  v3.size()<4;
  this.size()<4;
  this->size()<4;
  (this*).size()<4;
  
  return 0;
}
