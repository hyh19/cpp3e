#include <iostream>
using namespace std;

int main()
{
  cout << "Celsius 35 is Fahrenheit degree " << endl;
  cout << (9 / 5) * 35 + 32 << endl;

  return 0;
}
