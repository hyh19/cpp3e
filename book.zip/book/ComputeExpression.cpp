#include <iostream>
using namespace std;

int main()
{
  cout << "(10.5 + 2 * 3) / (45 - 3.5) = ";
  cout << (10.5 + 2 * 3) / (45 - 3.5) << endl;

  return 0;
}
