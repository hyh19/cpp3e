#include <iostream>
using namespace std;

int main()
{
  // Display Welcome to C++ to the console
  cout << "Welcome to C++!" << endl;

  return 0;
}
