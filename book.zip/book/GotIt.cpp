#include <iostream>
using namespace std;

int main()
{
  cout << "Got it!" << endl;
  cout << "Fundamentals First" << endl;
  cout << "Problem Driven" << endl;

  return 0;
}
