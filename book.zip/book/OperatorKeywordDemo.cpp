#include <iostream>
#include <iso646.h>
using namespace std;

int main()
{
  cout << (true and true) << endl;
  cout << (false and true) << endl;
  cout << (true && true) << endl;
  cout << (false && true) << endl;

  return 0;
}
