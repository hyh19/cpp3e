#include <iostream>
#include "MyLib.h"

using namespace std;

int main()
{
  cout << isEven(4) << endl;
  cout << isEven(5) << endl;

  return 0;
}
